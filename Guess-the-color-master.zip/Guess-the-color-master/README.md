# Guess-the-Color



This is a color guessing game in which you have to guess the color.It is based on RGB color combination.Developed by using HTML,CSS,Javascript.
